modelo_normal_bug <- function(){
  for(i in 1:n)
  {
    y[i] ~ dnorm(mu, tau)
  }
  mu ~  dnorm(mu_mu, mu_tau)
  tau ~  dgamma(tau_a,tau_b)
  sigma <- 1/sqrt(tau)
}

modelo_lognormal_bug <- function(){
  for(i in 1:n)
  {
    y[i] ~ dlnorm(mu, tau)
  }
  mu ~  dnorm(mu_mu, mu_tau)
  tau ~  dgamma(tau_a,tau_b)
  sigma <- 1/sqrt(tau)
}

modelo_gamma_bug <- function(){
  for(i in 1:n)
  {
    y[i] ~ dgamma(a, b)
  }
  a ~dgamma(aa,ab)
  b ~dgamma(aa,ab)
}

modelo_bernoulli_bug <- function(){
  for(i in 1:n)
  {
    y[i] ~ dbern(theta)
  }
  theta ~ dbeta(a,b)
}

modelo_poisson_bug <- function(){
  for(i in 1:n)
  {
    y[i] ~ dpois(theta)
  }
  theta ~ dgamma(a,b)
}

modelo_linear_simples_bug <- function(){
  for (i in 1 : n)
  {
    y[i] ~ dnorm(mu[i], tau)
    mu[i] <- beta0 + beta1* x[i]
  }
  beta0 ~  dnorm(beta_mu, beta_tau)
  beta1 ~  dnorm(beta_mu, beta_tau)
  tau ~ dgamma(tau_a, tau_b)
  sigma <- sqrt(1 /  tau)
  sigma2 <- pow(sigma,2)
  # Procedimento para obtenção do R2B (Coef. de Determinação Bayesiano)
  sy2 <- pow(sd(y[]),2)
  R2B <- 1 - sigma2/sy2
  # Cálculo de uma predição
  y.pred <- beta0 + beta1*x0
}

modelo_linear_quadratico_bug <- function(){
  for (i in 1 : n)
  {
    y[i] ~ dnorm(mu[i], tau)
    mu[i] <- beta0 + beta1*x[i] + beta2*pow(x[i],2)
  }
  # prioris
  beta0 ~  dnorm(beta_mu, beta_tau)
  beta1 ~  dnorm(beta_mu, beta_tau)
  beta2 ~  dnorm(beta_mu, beta_tau)
  tau ~ dgamma(tau_a, tau_b)
  sigma <- sqrt(1 /  tau)
  sigma2 <- pow(sigma,2)

  # Procedimento para obtenção do R2B (Coef. de Determinação Bayesiano)
  sy2 <- pow(sd(y[]),2)
  R2B <- 1 - sigma2/sy2

  # Cálculo de uma predição
  y.pred <- beta0 + beta1*x0 + beta2*pow(x0,2)

  # Coordenadas do ponto crítico
  PCx <- - (beta1/(2*beta2))
  PCy <- - ((pow(beta1,2)-4*beta2*beta0)/(4*beta2))
}

modelo_linear_multiplo_bug <- function(){
  for (i in 1:n)
  {
    y[i] ~ dnorm(mu[i], tau)
    mu[i] <- beta0 + inprod(x[i, ], beta[])
  }
  beta0 ~ dnorm(beta_mu, beta_tau)
  for (j in 1:p)
  {
    beta[j] ~ dnorm(beta_mu, beta_tau)
  }
  tau ~ dgamma(tau_a, tau_b)
  sigma <- 1/sqrt(tau)
}

modelo_dif_medias_normal_var_igual_bug <- function(){
  for( i in 1 : n1 ) { y1[i] ~ dnorm(mu1,tau) }
  for( j in 1 : n2 ) { y2[j] ~ dnorm(mu2,tau) }

  mu1 ~ dnorm( mu1_mu , mu1_tau)
  mu2 ~ dnorm( mu2_mu , mu2_tau)
  delta <- mu1 - mu2

  tau ~ dgamma(tau_a, tau_b)
  sigma <- 1 / sqrt(tau)
}#por uma opção de pedir gráficos sobrepostos

modelo_dif_medias_normal_var_dif_bug <- function(){
  for( i in 1 : n1 ) { y1[i] ~ dnorm(mu1,tau1) }
  for( j in 1 : n2 ) { y2[j] ~ dnorm(mu2,tau2) }

  mu1 ~ dnorm( mu1_mu , mu1_tau)
  mu2 ~ dnorm( mu2_mu , mu2_tau)
  delta_mu <- mu1 - mu2

  tau1 ~ dgamma(tau1_a, tau1_b)
  sigma1 <- 1 / sqrt(tau1)

  tau2 ~ dgamma(tau2_a, tau2_b)
  sigma2 <- 1 / sqrt(tau2)
  delta_sigma <- sigma1 - sigma2
}

modelo_normal_pareado_bug <- function(){
  for( i in 1:n )
  {
    dif[i] ~ dnorm(mu, tau)
  }
  mu ~  dnorm(mu_mu, mu_tau)
  tau ~  dgamma(tau_a,tau_b)
  sigma <- 1/sqrt(tau)
}

