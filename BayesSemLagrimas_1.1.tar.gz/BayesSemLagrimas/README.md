# pacotes

Versões do meu pacote BayesSemLagrimas, feito para ajudar a turma da disciplina Estatística Bayesiana da Universidade Estadual de Maringá

Qualquer coisa entrar em contato por <bruno.albuquerque1990@gmail.com>
