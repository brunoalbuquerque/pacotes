esquema_pacote('ggplot2')
esquema_pacote('data.table')

plotar_posterioris <- function(MCMC,plot_vars){
  dete <- data.table(stack(data.table(as.matrix(ajuste$MCMC[[1]][,plot_vars]))))
  gg_density <- ggplot(data = dete, aes(x=values))+
    geom_density(aes(group=ind,colour=ind,fill=ind),alpha=0.3)+
    guides(fill=guide_legend(title="Posteriori"),colour=guide_legend(title="Posteriori"))+
    theme_linedraw()
  gg_hist <- ggplot(data = dete, aes(x=values))+
    geom_histogram(bins = 50,aes(group=ind,colour=ind,fill=ind),alpha=.3)+
    guides(fill=guide_legend(title="Posteriori"),colour=guide_legend(title="Posteriori"))+
    theme_linedraw()
  gg <- list('Densidade_Kernel' = gg_density,
                  'Histograma' = gg_hist)
  return(gg)
}

