vlw_Bruno          <- function(dados,
                               modelo_bug,
                               parametros ,
                               chutes,
                               iteracoes = 10000,
                               burn = 1000,
                               salto = 1,
                               arredonda = 3,
                               semente = NULL,
                               renderiza=T){
  esquema_pacote('BRugs')
  esquema_pacote('coda')
  set.seed(semente)
  fit <- gambiarra(modelFile = modelo_bug,
                   data = dados,
                   inits = chutes,
                   numChains = 1,
                   parametersToSave = parametros,
                   nBurnin = burn,
                   nIter = iteracoes,
                   nThin = salto,
                   DIC = T,
                   coda = T,
                   digits = 5)
  if(as.character(c(modelo_bug)) ==  as.character(c(modelo_linear_multiplo_bug))){
    parms_interesse <- c(parms[c(1,4)],paste0("beta[",1:dados$p,"]"))
  } else {
    desmembrada <- strsplit(as.character(c(modelo_bug)),split = '\n')
    pos = grep('~', desmembrada[[1]])
    nospace <- gsub(" ", "", desmembrada[[1]][pos], fixed = TRUE)
    tirados <- sapply(strsplit(nospace,split = '~'),FUN = function(X) X[1])
    parms_interesse<- tirados[tirados %in% parametros]
  }

  n_chains <- ncol(as.matrix(fit$MCMC))
  resumo_maroto <- summary(object = fit$MCMC,quantiles = c(.025,.5,.975))
  convergencia <-heidel.diag(fit$MCMC)[[1]]
  if(n_chains==1) {
    resumo_lindo <- round(cbind(t(resumo_maroto$statistics[c(1,2)]),
                                t(resumo_maroto$quantiles),
                                'Sinal ICr'=sign(resumo_maroto$quantiles[1]* resumo_maroto$quantiles[3]),
                                t(convergencia[c(1,4)])),arredonda)
    rownames(resumo_lindo) <- parms_interesse
    colnames(resumo_lindo) <- c("Mean", "SD", "2.5%", "50%", "97.5%", "Sinal ICr", "stest",
                                "htest")

  } else {
    resumo_lindo <- round(cbind(resumo_maroto$statistics[,c(1,2)],
                                resumo_maroto$quantiles,
                                'Sinal ICr'=sign(resumo_maroto$quantiles[,1]* resumo_maroto$quantiles[,3]),
                                convergencia[,c(1,4)]),arredonda)
    resumo_lindo <- resumo_lindo[parametros,]
  }
  retornar <- list('Resumo' = resumo_lindo,
                   'MCMC' = fit$MCMC,
                   'convergencia' =convergencia,
                   'DIC' = fit$DIC)
  if(renderiza){
    tempDir <- tempfile()
    dir.create(tempDir)
    htmlFile <- file.path(tempDir, "test.html")
    viewer <- getOption('viewer')
    system.file("file.Rmd", package="packagename")
    md_output <- system.file('rmd/output.Rmd',package = "BayesSemLagrimas")
    rmarkdown::render(md_output,output_file = htmlFile,output_format = "html_document",quiet = F, params = list(
      interesse = parms_interesse,
      mcmc = fit$MCMC,
      saida = retornar
    ))
    viewer(htmlFile)
  }
  return(retornar)
}
